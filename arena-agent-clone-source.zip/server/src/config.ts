import "dotenv/config";
import {
  mkdirSync,
  existsSync,
  readFileSync,
  writeFileSync,
  chmodSync,
} from "node:fs";
import { resolve } from "node:path";
import { randomBytes } from "node:crypto";
import { z } from "zod";

const schema = z.object({
  PORT: z.coerce.number().int().min(1).max(65535).default(4310),
  HOST: z.string().default("127.0.0.1"),
  DATA_DIR: z.string().default("./data"),
  LOG_LEVEL: z.string().default("info"),
});
const parsed = schema.parse(process.env);
export const rootDir = resolve(process.cwd());
export const dataDir = resolve(rootDir, parsed.DATA_DIR);
export const workspacesDir = resolve(dataDir, "workspaces");
export const config = {
  port: parsed.PORT,
  host: parsed.HOST,
  logLevel: parsed.LOG_LEVEL,
  dataDir,
  workspacesDir,
};

export function initializeStorage(): void {
  mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  mkdirSync(workspacesDir, { recursive: true, mode: 0o700 });
  chmodSync(dataDir, 0o700);
  chmodSync(workspacesDir, 0o700);
  const secretPath = resolve(dataDir, ".secret");
  if (!existsSync(secretPath))
    writeFileSync(secretPath, randomBytes(32), { mode: 0o600, flag: "wx" });
  chmodSync(secretPath, 0o600);
}
export function readSecret(): Buffer {
  return readFileSync(resolve(dataDir, ".secret"));
}
