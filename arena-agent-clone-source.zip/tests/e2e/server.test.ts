import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { spawn, type ChildProcess } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

let child: ChildProcess | undefined;
let dataDir = "";
const port = 4318;
const base = `http://127.0.0.1:${port}`;
beforeAll(async () => {
  dataDir = await mkdtemp(join(tmpdir(), "arena-agent-e2e-"));
  child = spawn(process.execPath, ["server/dist/index.js"], {
    cwd: process.cwd(),
    env: {
      ...process.env,
      HOST: "127.0.0.1",
      PORT: String(port),
      DATA_DIR: dataDir,
      LOG_LEVEL: "error",
    },
    stdio: "ignore",
  });
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${base}/api/health`);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error("Local server did not become healthy within 20 seconds.");
}, 25000);
afterAll(async () => {
  if (child?.pid) {
    child.kill("SIGTERM");
    await new Promise<void>((resolve) => {
      const timeout = setTimeout(resolve, 3000);
      child?.once("exit", () => {
        clearTimeout(timeout);
        resolve();
      });
    });
  }
  if (dataDir) await rm(dataDir, { recursive: true, force: true });
});

describe("production HTTP smoke test", () => {
  it("serves health and creates a persistent no-auth session", async () => {
    const health = await fetch(`${base}/api/health`);
    expect(health.status).toBe(200);
    expect((await health.json()).ok).toBe(true);
    const create = await fetch(`${base}/api/sessions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    expect(create.status).toBe(201);
    const session = (await create.json()) as { id: string };
    const get = await fetch(`${base}/api/sessions/${session.id}`);
    expect(get.status).toBe(200);
    expect((await get.json()).runStatus).toBe("idle");
  });

  it("accepts safe text uploads and rejects an executable extension", async () => {
    const created = await fetch(`${base}/api/sessions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const session = (await created.json()) as { id: string };
    const form = new FormData();
    form.append(
      "files",
      new Blob(["# Uploaded locally\n"], { type: "text/markdown" }),
      "note.md",
    );
    const uploaded = await fetch(`${base}/api/sessions/${session.id}/upload`, {
      method: "POST",
      body: form,
    });
    expect(uploaded.status).toBe(200);
    const file = (await uploaded.json()).files[0] as { path: string };
    expect(
      await (
        await fetch(
          `${base}/api/sessions/${session.id}/file?path=${encodeURIComponent(file.path)}`,
        )
      ).text(),
    ).toContain("Uploaded locally");
    const denied = new FormData();
    denied.append(
      "files",
      new Blob(["echo unsafe"], { type: "text/plain" }),
      "bad.sh",
    );
    expect(
      (
        await fetch(`${base}/api/sessions/${session.id}/upload`, {
          method: "POST",
          body: denied,
        })
      ).status,
    ).toBe(415);
  });

  it("starts and proxies a real loopback preview, rewrites app-root assets, and stops it", async () => {
    const created = await fetch(`${base}/api/sessions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const session = (await created.json()) as { id: string };
    const previewPort = port + 1;
    const command = `node -e 'require("http").createServer((q,r)=>{r.setHeader("content-type","text/html");r.end("<html><head></head><body><script src=\\\"/app.js\\\"></script></body></html>")}).listen(${previewPort},"127.0.0.1")'`;
    const start = await fetch(
      `${base}/api/sessions/${session.id}/previews/start`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ command, port: previewPort, timeoutMs: 8000 }),
      },
    );
    expect(start.status).toBe(201);
    const preview = await fetch(
      `${base}/preview/${session.id}/${previewPort}/`,
    );
    expect(preview.status).toBe(200);
    expect(await preview.text()).toContain(
      `/preview/${session.id}/${previewPort}/app.js`,
    );
    const stopped = await fetch(
      `${base}/api/sessions/${session.id}/previews/stop`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: "{}",
      },
    );
    expect((await stopped.json()).stopped).toBe(1);
  });

  it("clears the persisted conversation and cost ledger while preserving session workspace state", async () => {
    const created = await fetch(`${base}/api/sessions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ title: "clear-test" }),
    });
    const session = (await created.json()) as { id: string };
    const cleared = await fetch(`${base}/api/sessions/${session.id}/messages`, {
      method: "DELETE",
    });
    expect(cleared.status).toBe(200);
    const state = await (
      await fetch(`${base}/api/sessions/${session.id}`)
    ).json();
    expect(state.messages).toEqual([]);
    expect(state.total_cost_usd).toBe(0);
  });
});
