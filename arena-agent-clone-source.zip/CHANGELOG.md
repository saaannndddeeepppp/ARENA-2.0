# Changelog

## 1.0.0 — Local agent core

- Added local SQLite session persistence and encrypted provider keys.
- Added live provider model discovery and streaming adapters for OpenAI-compatible APIs, Gemini native, and Anthropic.
- Added SSE-backed agent loops and workspace shell/file/web tools.
- Added a responsive chat UI with local session history, tool cards, provider settings, workspace tree, artifact viewer, and exports.

## Local workflow completion pass

- Added encrypted GitHub PAT connection, repository selection, session clone/branch workflow, Git lifecycle/PR/check tools, live diff panel, and post-PR workspace lock enforcement.
- Added a real loopback preview process manager and same-origin iframe proxy with file-change reload and multiple preview selection.
- Persisted sequenced SSE replay in SQLite and added interrupted-session continuation from transcript/workspace state.
- Added command palette/shortcut/slash actions, clipboard file staging, safe-format upload validation, clear-session/cost APIs, and expanded upload/preview end-to-end tests.
- Restored the full dark-theme stylesheet and captured an updated local preview screenshot.
